# Topics in R, UCI DSI
# 2 Dec 2016
# Dustin Pluta
# dpluta@uci.edu

install.packages("dplyr")
install.packages("maps")

library(dplyr)
library(ggplot2)
library(maps)
library(microbenchmark)

dat <- read.csv("GlobalTemperatures.csv")

colnames(dat)

plot(dat$LandAverageTemperature, ty="l")
dat <- mutate(dat, date = as.Date(dt))

plot(dat$date, dat$LandAverageTemperature)

k <- 365
dat <-  mutate(dat, SmoothedAvg = stats::filter(LandAverageTemperature,
                                           rep(1/k, k), sides=2))
# Now using %>%
k <- 100
dat_global <- read.csv("GlobalTemperatures.csv") %>%
    mutate(date = as.Date(dt)) %>%
    mutate(SmoothedAvg = stats::filter(LandAverageTemperature,
                                       rep(1/k, k), sides=2))

ggplot(dat_global, aes(date, SmoothedAvg)) +
    geom_line()

# Plot Temp for Selected Cities
